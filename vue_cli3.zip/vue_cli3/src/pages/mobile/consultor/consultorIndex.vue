<!--
 * @author: wangshuaixue
 * @Date: 2019-12-18
 * @description 移动端咨询师侧
 -->
<template>
  <router-view/>
</template>

<script>
export default {
  name: 'consultorIndex',
  data () {
    return {}
  }
}
</script>

<style lang="less" scoped>
</style>
