<template>
  <router-view/>
</template>

<script>
export default {
  name: 'cityIndex',
  data () {
    return {}
  }
}
</script>
<style lang="less" scoped>
</style>
