import BuildingCompare from './BuildingCompare'
import HouseInfoContrast from './HouseInfoContrast'
import BuildingIndex from './BuildingIndex'
import DialogDemo from './DialogDemo'
export {BuildingCompare, HouseInfoContrast, BuildingIndex, DialogDemo}
