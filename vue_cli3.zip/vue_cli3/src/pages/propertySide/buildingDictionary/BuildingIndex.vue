<template>
  <router-view/>
</template>

<script>
export default {
  name: 'building',
  data () {
    return {}
  }
}
</script>
<style lang="less" scoped>
</style>
