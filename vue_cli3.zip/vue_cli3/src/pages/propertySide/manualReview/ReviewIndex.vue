<template>
  <router-view/>
</template>

<script>
export default {
  name: 'ReviewIndex',
  data () {
    return {}
  }
}
</script>
<style lang="less" scoped>
</style>
