<template>
  <router-view/>
</template>

<script>
export default {
  name: 'payment',
  data () {
    return {}
  }
}
</script>
<style lang="less" scoped>
</style>
