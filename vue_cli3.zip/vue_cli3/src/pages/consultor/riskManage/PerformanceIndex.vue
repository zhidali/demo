<!--
 * @author: wangshuaixue
 * @Date: 2019-08-09 10:20:38
 * @description
 -->
<template>
  <router-view/>
</template>

<script>
export default {
  name: 'Performance',
  data () {
    return {}
  }
}
</script>

<style lang="less" scoped>
</style>
