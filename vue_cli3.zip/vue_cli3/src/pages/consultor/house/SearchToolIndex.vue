<!--
 * @Name: 找房工具总页面
 * @Description: 找房工具总页面
 * @Author: wangshuaixue
 * @Date: 2019-12-19
 -->
<template>
<router-view class="search-tool" />
</template>

<script>
export default {
    name: 'searchToolIndex'
}
</script>

<style lang="less" scoped>
</style>
