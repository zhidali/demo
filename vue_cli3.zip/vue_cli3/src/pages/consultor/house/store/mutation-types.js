// 找房工具文章页楼盘信息
export const GET_ARTICLE_INFO = 'get_article_info';
// 通勤地址记录
export const GET_COMMU = 'get_commu'