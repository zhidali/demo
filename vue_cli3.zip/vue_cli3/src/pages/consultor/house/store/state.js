export default {
    // 通勤地址
    commuLoc: {},
    // 文章楼盘数据
    articleProInfo: []
}