<!--
 * @Name: sop总页面
 * @Description: sop总页面
 * @Author: wangshuaixue
 * @Date: 2019-12-18
 -->
<template>
<router-view class="sop-container" />
</template>

<script>
export default {
    name: 'sopContainer'
}
</script>

<style lang="less" scoped>
</style>
