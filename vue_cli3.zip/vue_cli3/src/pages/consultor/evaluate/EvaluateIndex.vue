
<!--
 * @Name: 评价
 * @Description: 评价基础页
 * @Author: zhengchao
 * @Date: 2019-12-03
-->
<template>
  <router-view/>
</template>

<script>
export default {
  name: 'Evaluate',
  data () {
    return {}
  }
}
</script>

<style lang="less" scoped>
</style>
