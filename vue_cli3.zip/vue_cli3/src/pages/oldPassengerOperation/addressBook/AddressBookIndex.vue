<!--
 * @Name: 微信通信录主页面
 * @Description: 微信通信录主页面
 * @Author: baiyunfei
 * @Date: 2019-09-24 15:50:36
 * @Editors: baiyunfei
 -->
<template>
<router-view class="address-book" />
</template>

<script>
export default {
    name: 'addressBook'
}
</script>

<style lang="less" scoped>
.address-book {
    padding: 0 20px 30px;
}

</style>
