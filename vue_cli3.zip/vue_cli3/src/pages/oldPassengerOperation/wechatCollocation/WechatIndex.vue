<template>
  <router-view/>
</template>

<script>
export default {
  name: 'wechat',
  data () {
    return {}
  }
}
</script>
<style lang="less" scoped>
</style>
