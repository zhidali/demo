<template>
  <router-view/>
</template>

<script>
export default {
  name: 'paper-index',
  data () {
    return {}
  }
}
</script>
<style lang="less" scoped>
</style>
