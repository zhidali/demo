<template>
  <router-view/>
</template>

<script>
export default {
  name: 'rateIndex',
  data () {
    return {}
  }
}
</script>
<style lang="less" scoped>
</style>
