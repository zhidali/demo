<!--
    @file: 公共底部
    @updater: xiejiaxin
-->
<template>
  <div class="jl-footer">
    <span>北京高因科技有限公司</span>
    <span>www.julive.com</span>
  </div>
</template>

<style scoped>
.jl-footer{
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: #2f3742;
  height: 116px;
}
.jl-footer span{
  color: #606c7d;
  font-size: 12px;
  margin-right: 8px;
}
</style>
