/**
 * @author Sakura
 * Date: 2019/5/22 5:25 PM
 * update: 路径迁移到config文件加下
 * updater: xiejiaxin
 */
export default {
  'OSS_ACCESS_ID': 'RMF4pIIDkr17zozQ', // 阿里云ACCESS_ID
  'OSS_ACCESS_KEY': 'R8KMJmXe2uHKt8X7Zfwtrm9kkoA7g3' // 阿里云ACCESS_KEY
}
